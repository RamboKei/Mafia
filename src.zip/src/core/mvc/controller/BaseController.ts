/**
 * author 陈可
 * date 2017/9/11
 * @class BaseController
 */
abstract class BaseController extends BaseClass
{
	public constructor() 
	{
		super();
	}

	abstract dispose():void;
}