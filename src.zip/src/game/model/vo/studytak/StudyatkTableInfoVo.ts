/**
 * 演武场
 * author yanyuling
 * date 2017/11/28
 * @class StudyatkTableInfoVo
 */
class StudyatkTableInfoVo extends BaseVo
{
	// 门客vo列表
	public atklist = [];
	public constructor() 
	{
		super();
	}

	public initData(data:any):void
	{
        if(data.studyatk)
        {
            
        }
    }

    public dispose()
    {

    }
}