class AcRankActiveVo extends AcBaseVo
{
	public constructor() 
	{
		super();
	}
}