class AcVoApi extends AcBaseVoApi
{
	public constructor() 
	{
		super();
	}
}