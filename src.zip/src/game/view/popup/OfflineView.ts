/**
 * 踢下线面板
 * author dky
 * date 2017/11/24
 * @class ConfirmPopupView
 * 参数 ：title,msg,callback,handler 
 * 
 */
class OfflineView extends ConfirmPopupView
{
    
}