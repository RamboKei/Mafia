abstract class PopupViewTab extends ViewTab
{
	public constructor() 
	{
		super();
	}
}